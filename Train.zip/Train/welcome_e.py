# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'welcome.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
###########################################
from login_e import Ui_login_page
###########################################
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_welcome_page(object):
    def setupUi(self, welcome_page):
        welcome_page.setObjectName(_fromUtf8("welcome_page"))
        welcome_page.resize(400, 300)
        self.label = QtGui.QLabel(welcome_page)
        self.label.setGeometry(QtCore.QRect(20, 40, 401, 161))
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setBold(True)
        font.setUnderline(False)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.proceed_btn = QtGui.QPushButton(welcome_page)
        self.proceed_btn.setGeometry(QtCore.QRect(180, 220, 191, 61))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.proceed_btn.setFont(font)
        self.proceed_btn.setObjectName(_fromUtf8("proceed_btn"))
##############################################################
        self.proceed_btn.clicked.connect(self.ln)           #connected ln() function on click
##############################################################
        self.cancel_btn = QtGui.QPushButton(welcome_page)
        self.cancel_btn.setGeometry(QtCore.QRect(20, 220, 141, 61))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.cancel_btn.setFont(font)
        self.cancel_btn.setObjectName(_fromUtf8("cancel_btn"))
        #######################CANCEL BUTTON#################################
        self.cancel_btn.clicked.connect(QtCore.QCoreApplication.instance().quit)
        #######################################################################
        self.retranslateUi(welcome_page)
        QtCore.QMetaObject.connectSlotsByName(welcome_page)

    def retranslateUi(self, welcome_page):
        welcome_page.setWindowTitle(_translate("welcome_page", "WELCOME", None))
        self.label.setText(_translate("welcome_page", "WELCOME  TO INDIAN RAILWAY RESERVATION ", None))
        self.proceed_btn.setText(_translate("welcome_page", "PROCEED TO APP ---->", None))
        self.cancel_btn.setText(_translate("welcome_page", "CANCEL", None))
        
########################################################
    def ln(self):
        self.login = QtGui.QDialog()                      #copy 
        self.ui = Ui_login_page()
        self.ui.setupUi(self.login)
        self.login.show()
########################################################

if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    welcome_page = QtGui.QWidget()
    ui = Ui_welcome_page()
    ui.setupUi(welcome_page)
    welcome_page.show()
    sys.exit(app.exec_())

