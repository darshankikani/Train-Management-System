# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'updatewindow.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_update_window(object):
    def setupUi(self, update_window):
        update_window.setObjectName(_fromUtf8("update_window"))
        update_window.resize(400, 300)
        self.label = QtGui.QLabel(update_window)
        self.label.setGeometry(QtCore.QRect(110, 20, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(update_window)
        self.label_2.setGeometry(QtCore.QRect(20, 80, 141, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.lineEdit_oldPass = QtGui.QLineEdit(update_window)
        self.lineEdit_oldPass.setGeometry(QtCore.QRect(180, 70, 191, 31))
        self.lineEdit_oldPass.setEchoMode(QtGui.QLineEdit.Password)
        self.lineEdit_oldPass.setObjectName(_fromUtf8("lineEdit_oldPass"))
        self.label_3 = QtGui.QLabel(update_window)
        self.label_3.setGeometry(QtCore.QRect(20, 140, 151, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_3.setFont(font)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.lineEdit_NewPass = QtGui.QLineEdit(update_window)
        self.lineEdit_NewPass.setGeometry(QtCore.QRect(180, 130, 191, 31))
        self.lineEdit_NewPass.setEchoMode(QtGui.QLineEdit.Password)
        self.lineEdit_NewPass.setObjectName(_fromUtf8("lineEdit_NewPass"))
        self.label_4 = QtGui.QLabel(update_window)
        self.label_4.setGeometry(QtCore.QRect(20, 190, 161, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_4.setFont(font)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.lineEdit_Updatecontact = QtGui.QLineEdit(update_window)
        self.lineEdit_Updatecontact.setGeometry(QtCore.QRect(180, 190, 191, 31))
        self.lineEdit_Updatecontact.setObjectName(_fromUtf8("lineEdit_Updatecontact"))
        self.pushButton_update = QtGui.QPushButton(update_window)
        self.pushButton_update.setGeometry(QtCore.QRect(110, 250, 181, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_update.setFont(font)
        self.pushButton_update.setObjectName(_fromUtf8("pushButton_update"))

        self.retranslateUi(update_window)
        QtCore.QMetaObject.connectSlotsByName(update_window)

    def retranslateUi(self, update_window):
        update_window.setWindowTitle(_translate("update_window", "Form", None))
        self.label.setText(_translate("update_window", "Update Details", None))
        self.label_2.setText(_translate("update_window", "Old Password :", None))
        self.label_3.setText(_translate("update_window", "New Password : ", None))
        self.label_4.setText(_translate("update_window", "Update Contact : ", None))
        self.pushButton_update.setText(_translate("update_window", "UPDATE", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    update_window = QtGui.QWidget()
    ui = Ui_update_window()
    ui.setupUi(update_window)
    update_window.show()
    sys.exit(app.exec_())

