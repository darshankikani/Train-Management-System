# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'book.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_book(object):
    def setupUi(self, book):
        book.setObjectName(_fromUtf8("book"))
        book.resize(400, 300)
        self.pushButton_book = QtGui.QPushButton(book)
        self.pushButton_book.setGeometry(QtCore.QRect(120, 100, 151, 81))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_book.setFont(font)
        self.pushButton_book.setObjectName(_fromUtf8("pushButton_book"))

        self.retranslateUi(book)
        QtCore.QMetaObject.connectSlotsByName(book)

    def retranslateUi(self, book):
        book.setWindowTitle(_translate("book", "Form", None))
        self.pushButton_book.setText(_translate("book", "BOOK NOW", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    book = QtGui.QWidget()
    ui = Ui_book()
    ui.setupUi(book)
    book.show()
    sys.exit(app.exec_())

