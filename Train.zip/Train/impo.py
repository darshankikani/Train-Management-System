        #############################################
        x=self.lineEdit_entTrainNo.text()
        db=sqlite3.connect('trainDetails.db')
        cursor=db.cursor()
        cursor.execute('''SELECT TRAINNO,TRAIN_NAME,TRAIN_FROM,TRAIN_TO,SUN,MON,TUE,WED,THURS,FRI,SAT FROM traininfo WHERE TRAINNO=?''',(x,))
        allrows=cursor.fetchall()
        for row in allrows:
            print(row[0])
        y=self.lineEdit_entTrainNo.text()
        if(x=='12345'):
            print("hello World")
            self.lineEdit_tname.setText(row[1])
            self.lineEdit_from.setText(row[2])
            self.lineEdit_to.setText(row[3])
            self.lineEdit_sun.setText(row[4])
            self.lineEdit_mon.setText(row[5])
            self.lineEdit_tue.setText(row[6])
            self.lineEdit_wed.setText(row[7])
            self.lineEdit_thurs.setText(row[8])
            self.lineEdit_fri.setText(row[9])
            self.lineEdit_sat.setText(row[10])
            
#############################################
