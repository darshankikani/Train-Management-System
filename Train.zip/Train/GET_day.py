import datetime
#import sqlite3
year=int(input("Enter year :"))
month=int(input("Enter month :"))
day=int(input("Enter day :"))
DayL = ['Mon','Tues','Wednes','Thurs','Fri','Satur','Sun']
date = DayL[datetime.date(year,month,day).weekday()] + 'day'
print(date)
