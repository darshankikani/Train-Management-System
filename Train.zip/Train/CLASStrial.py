class name():
   x='shivam'
   def myname(self):
      print(self.x)

abc=name()
abc.myname()
