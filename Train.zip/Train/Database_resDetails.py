import sqlite3
conn = sqlite3.connect('userResDet.db')
c=conn.cursor()
def createTable():

    c.execute("CREATE TABLE IF NOT EXISTS reservationDetails(UniqueID TEXT ,User_Name TEXT,Age TEXT,Gender TEXT,Booked Train TEXT, TravelDate TEXT, NoOfPassengers TEXT,BookedSeats TEXT,SeniorCitizen TEXT, NoOfSeniorCitizen TEXT,SeatNo TEXT, BoggieNo TEXT,Quota TEXT,TotalSeats TEXT, TotalFare TEXT)")

    conn.commit()
    c.close()
##def read():
##    c.execute("SELECT * FROM USERINFO")
##    for row in c.fetchall():
##        print(row)






##read()
createTable()    
