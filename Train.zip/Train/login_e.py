# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'login.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from signup_withDB_e import Ui_signup_page
from dashboard import Ui_dashboard
import sqlite3
from adminwindow import Ui_admin
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_login_page(object):

    def showMessageBox(self,title,message):
        msgBox = QtGui.QMessageBox()
        msgBox.setIcon(QtGui.QMessageBox.Warning)
        msgBox.setWindowTitle(title)
        msgBox.setText(message)
        msgBox.setStandardButtons(QtGui.QMessageBox.Ok)
        msgBox.exec_()
##    def welcomeWindowShow(self):
##        self.welcomeWindow = QtGui.QMainWindow()
##        self.ui = Ui_MainWindow()
##        self.ui.setupUi(self.welcomeWindow)
##        self.welcomeWindow.show()
##    def signUpShow(self):
##        self.signUpWindow = QtGui.QDialog()
##        self.ui = Ui_signUp()
##        self.ui.setupUi(self.signUpWindow)
#        self.signUpWindow.show()
    def loginCheck(self):
        global fname
        fname = self.lineedit_name.text()
        password = self.lineedit_password.text()

        db= sqlite3.connect("UserDetails.db")
        cursor=db.cursor()
        cursor.execute("SELECT FNAME,PASSWORD FROM USERINFO WHERE FNAME = ? AND PASSWORD = ?",(fname,password))
        aaa=cursor.fetchone()
        
            
        result = cursor.execute("SELECT FNAME,PASSWORD FROM USERINFO WHERE FNAME = ? AND PASSWORD = ?",(fname,password))
        if(len(result.fetchall()) > 0):
            if(fname=='shivam' and password==aaa[1]):
                self.adwin()
        
            else:
                print("User Found ! ")
                cursor.execute('''SELECT MNAME,LNAME,USERID,CONTACT FROM userinfo WHERE fname=?''',(fname,))
                allrows=cursor.fetchall()
                for row in allrows:
                    print(row[0],row[1],row[2],row[3])
                self.dsh()
                #self.welcomeWindowShow()
        else:
           
            print("User Not Found !")
            self.showMessageBox('Warning','Invalid Username And Password')

        cursor.close()
        
    def setupUi(self, login_page):
        login_page.setObjectName(_fromUtf8("login_page"))
        login_page.resize(615, 368)
        font = QtGui.QFont()
        font.setPointSize(16)
        login_page.setFont(font)
        self.label = QtGui.QLabel(login_page)
        self.label.setGeometry(QtCore.QRect(220, 10, 201, 71))
        font = QtGui.QFont()
        font.setPointSize(33)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(True)
        font.setWeight(50)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.label_name = QtGui.QLabel(login_page)
        self.label_name.setGeometry(QtCore.QRect(40, 110, 131, 41))
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_name.setFont(font)
        self.label_name.setObjectName(_fromUtf8("label_name"))
        self.lineedit_name = QtGui.QLineEdit(login_page)
        self.lineedit_name.setGeometry(QtCore.QRect(200, 110, 381, 31))
        self.lineedit_name.setObjectName(_fromUtf8("lineedit_name"))
        self.label_password = QtGui.QLabel(login_page)
        self.label_password.setGeometry(QtCore.QRect(40, 200, 161, 51))
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_password.setFont(font)
        self.label_password.setObjectName(_fromUtf8("label_password"))
        self.lineedit_password = QtGui.QLineEdit(login_page)
        self.lineedit_password.setGeometry(QtCore.QRect(200, 210, 381, 31))
        self.lineedit_password.setEchoMode(QtGui.QLineEdit.Password)
        self.lineedit_password.setObjectName(_fromUtf8("lineedit_password"))
        self.login_btn = QtGui.QPushButton(login_page)
        self.login_btn.setGeometry(QtCore.QRect(390, 300, 211, 51))
        font = QtGui.QFont()
        font.setBold(False)
        font.setUnderline(True)
        font.setWeight(50)
        self.login_btn.setFont(font)
        self.login_btn.setObjectName(_fromUtf8("login_btn"))
        self.login_btn.clicked.connect(self.loginCheck)
        self.cancel_btn = QtGui.QPushButton(login_page)
        self.cancel_btn.setGeometry(QtCore.QRect(200, 300, 171, 51))
        self.cancel_btn.setObjectName(_fromUtf8("cancel_btn"))
        #######################CANCEL BUTTON#################################
        self.cancel_btn.clicked.connect(QtCore.QCoreApplication.instance().quit)
        #######################################################################
        self.signup_btn = QtGui.QPushButton(login_page)
        self.signup_btn.setGeometry(QtCore.QRect(10, 300, 171, 51))
        self.signup_btn.setObjectName(_fromUtf8("signup_btn"))
        self.signup_btn.clicked.connect(self.sp)
        self.retranslateUi(login_page)
        QtCore.QMetaObject.connectSlotsByName(login_page)

    def retranslateUi(self, login_page):
        login_page.setWindowTitle(_translate("login_page", "Form", None))
        self.label.setText(_translate("login_page", "LOGIN", None))
        self.label_name.setText(_translate("login_page", "NAME :", None))
        self.label_password.setText(_translate("login_page", "PASSWORD :", None))
        self.login_btn.setText(_translate("login_page", "LOGIN NOW -->", None))
        self.cancel_btn.setText(_translate("login_page", "CANCEL", None))
        self.signup_btn.setText(_translate("login_page", "SIGN UP", None))

    def sp(self):
##        app = signup.QtGui.QApplication(sys.argv)
##        signup_page = signup.QtGui.QWidget()
##        ui = signup.Ui_signup_page()
        self.signUp = QtGui.QDialog()
        self.ui =Ui_signup_page()
        self.ui.setupUi(self.signUp)
        self.signUp.show()
##        sys.exit(app.exec_())
    def check(self):
        print(self.Ui_signup_page.fname)
        
    def dsh(self):
        global fname
        self.dash = QtGui.QTabWidget()
        #app = QtGui.QApplication(sys.argv)
        #dashboard = QtGui.QTabWidget()
        self.ui = Ui_dashboard(fname)
        self.ui.setupUi(self.dash)
        self.dash.show()
        #sys.exit(app.exec_())
    def printme():
        print("helo world")

    def adwin(self):
        self.admin = QtGui.QTabWidget()
        self.ui = Ui_admin()
        self.ui.setupUi(self.admin)
        self.admin.show()
       
       
        
        
if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    login_page = QtGui.QWidget()
    ui = Ui_login_page()
    ui.setupUi(login_page)
    login_page.show()
    sys.exit(app.exec_())
    

