import sqlite3
conn = sqlite3.connect('UserDetails.db')
c=conn.cursor()
def createTable():

    c.execute("CREATE TABLE IF NOT EXISTS USERINFO(FNAME TEXT NOT NULL,MNAME TEXT,LNAME TEXT,EMAIL TEXT,USERID TEXT,CONTACT TEXT,PASSWORD TEXT,DOB DATE,NATIONALITY TEXT,COUNTRY TEXT,PINCODE TEXT,STATE TEXT,CITY TEXT,FULLADDRESS TEXT)")
def data_entry():
    
    c.execute("INSERT INTO USERINFO VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",('shivam','vikas','kolhe','kolhe.shivam17@gmail.com'
                                                                                     ,'shivam17','8980622789','abcd1234'
                                                                                     ,'17-12-1997','indian','india','385001','gujarat',
                                                                                     'palanpur','treasure residency'))

    conn.commit()
    c.close()
##def read():
##    c.execute("SELECT * FROM USERINFO")
##    for row in c.fetchall():
##        print(row)






##read()
createTable()
data_entry()        
    
