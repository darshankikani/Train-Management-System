import sqlite3
conn = sqlite3.connect('trainDetails.db')
c=conn.cursor()
def createTable():

    c.execute("CREATE TABLE IF NOT EXISTS traininfo(Srno INTEGER,TRAINNO TEXT ,TRAIN_NAME TEXT,TRAIN_FROM TEXT, TRAIN_TO TEXT, SUN TEXT, MON TEXT, TUE TEXT, WED TEXT, THURS TEXT, FRI TEXT, SAT TEXT,RATE TEXT)")
    #c.execute("ALTER TABLE traininfo ADD COLUMN 'Srno' INTEGER")
    conn.commit()
    c.close()
##def read():
##    c.execute("SELECT * FROM USERINFO")
##    for row in c.fetchall():
##        print(row)






##read()
createTable()    
