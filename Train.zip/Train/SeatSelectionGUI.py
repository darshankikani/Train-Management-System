# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SeatSelectionGUI.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from PassengerDetails import Ui_Passenger_Details
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Seat(object):
    def setupUi(self, Seat):
        Seat.setObjectName(_fromUtf8("Seat"))
        Seat.resize(671, 477)
        font = QtGui.QFont()
        font.setPointSize(8)
        Seat.setFont(font)
        self.line = QtGui.QFrame(Seat)
        self.line.setGeometry(QtCore.QRect(130, 110, 411, 20))
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.line_2 = QtGui.QFrame(Seat)
        self.line_2.setGeometry(QtCore.QRect(120, 120, 16, 241))
        self.line_2.setFrameShape(QtGui.QFrame.VLine)
        self.line_2.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_2.setObjectName(_fromUtf8("line_2"))
        self.lineEdit = QtGui.QLineEdit(Seat)
        self.lineEdit.setGeometry(QtCore.QRect(200, 120, 41, 241))
        self.lineEdit.setReadOnly(True)
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.lineEdit_2 = QtGui.QLineEdit(Seat)
        self.lineEdit_2.setGeometry(QtCore.QRect(242, 120, 291, 41))
        self.lineEdit_2.setReadOnly(True)
        self.lineEdit_2.setObjectName(_fromUtf8("lineEdit_2"))
        self.lineEdit_3 = QtGui.QLineEdit(Seat)
        self.lineEdit_3.setGeometry(QtCore.QRect(240, 320, 291, 41))
        self.lineEdit_3.setReadOnly(True)
        self.lineEdit_3.setObjectName(_fromUtf8("lineEdit_3"))
        self.lineEdit_4 = QtGui.QLineEdit(Seat)
        self.lineEdit_4.setGeometry(QtCore.QRect(130, 120, 51, 61))
        self.lineEdit_4.setReadOnly(True)
        self.lineEdit_4.setObjectName(_fromUtf8("lineEdit_4"))
        self.lineEdit_5 = QtGui.QLineEdit(Seat)
        self.lineEdit_5.setGeometry(QtCore.QRect(130, 300, 51, 61))
        self.lineEdit_5.setReadOnly(True)
        self.lineEdit_5.setObjectName(_fromUtf8("lineEdit_5"))
        self.line_3 = QtGui.QFrame(Seat)
        self.line_3.setGeometry(QtCore.QRect(530, 120, 20, 241))
        self.line_3.setFrameShape(QtGui.QFrame.VLine)
        self.line_3.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_3.setObjectName(_fromUtf8("line_3"))
        self.line_4 = QtGui.QFrame(Seat)
        self.line_4.setGeometry(QtCore.QRect(320, 120, 20, 41))
        self.line_4.setFrameShape(QtGui.QFrame.VLine)
        self.line_4.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_4.setObjectName(_fromUtf8("line_4"))
        self.line_5 = QtGui.QFrame(Seat)
        self.line_5.setGeometry(QtCore.QRect(430, 120, 20, 41))
        self.line_5.setFrameShape(QtGui.QFrame.VLine)
        self.line_5.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_5.setObjectName(_fromUtf8("line_5"))
        self.line_6 = QtGui.QFrame(Seat)
        self.line_6.setGeometry(QtCore.QRect(320, 320, 20, 41))
        self.line_6.setFrameShape(QtGui.QFrame.VLine)
        self.line_6.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_6.setObjectName(_fromUtf8("line_6"))
        self.line_7 = QtGui.QFrame(Seat)
        self.line_7.setGeometry(QtCore.QRect(430, 320, 20, 41))
        self.line_7.setFrameShape(QtGui.QFrame.VLine)
        self.line_7.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_7.setObjectName(_fromUtf8("line_7"))
        self.checkBox_s1 = QtGui.QCheckBox(Seat)
        self.checkBox_s1.setGeometry(QtCore.QRect(150, 190, 41, 20))
        self.checkBox_s1.setObjectName(_fromUtf8("checkBox_s1"))
        self.checkBox_s2 = QtGui.QCheckBox(Seat)
        self.checkBox_s2.setGeometry(QtCore.QRect(150, 270, 41, 20))
        self.checkBox_s2.setObjectName(_fromUtf8("checkBox_s2"))
        self.checkBox_s3 = QtGui.QCheckBox(Seat)
        self.checkBox_s3.setGeometry(QtCore.QRect(280, 180, 81, 20))
        self.checkBox_s3.setObjectName(_fromUtf8("checkBox_s3"))
        self.checkBox_s4 = QtGui.QCheckBox(Seat)
        self.checkBox_s4.setGeometry(QtCore.QRect(380, 180, 81, 20))
        self.checkBox_s4.setObjectName(_fromUtf8("checkBox_s4"))
        self.checkBox_s5 = QtGui.QCheckBox(Seat)
        self.checkBox_s5.setGeometry(QtCore.QRect(480, 180, 81, 20))
        self.checkBox_s5.setObjectName(_fromUtf8("checkBox_s5"))
        self.checkBox_s6 = QtGui.QCheckBox(Seat)
        self.checkBox_s6.setGeometry(QtCore.QRect(280, 280, 81, 20))
        self.checkBox_s6.setObjectName(_fromUtf8("checkBox_s6"))
        self.checkBox_s6_2 = QtGui.QCheckBox(Seat)
        self.checkBox_s6_2.setGeometry(QtCore.QRect(380, 280, 81, 20))
        self.checkBox_s6_2.setObjectName(_fromUtf8("checkBox_s6_2"))
        self.checkBox_s7 = QtGui.QCheckBox(Seat)
        self.checkBox_s7.setGeometry(QtCore.QRect(480, 280, 81, 20))
        self.checkBox_s7.setObjectName(_fromUtf8("checkBox_s7"))
        self.line_8 = QtGui.QFrame(Seat)
        self.line_8.setGeometry(QtCore.QRect(120, 350, 421, 20))
        self.line_8.setFrameShape(QtGui.QFrame.HLine)
        self.line_8.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_8.setObjectName(_fromUtf8("line_8"))
        self.label = QtGui.QLabel(Seat)
        self.label.setGeometry(QtCore.QRect(200, 30, 301, 51))
        font = QtGui.QFont()
        font.setPointSize(23)
        font.setUnderline(True)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.pushButton = QtGui.QPushButton(Seat)
        self.pushButton.setGeometry(QtCore.QRect(230, 390, 211, 41))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.pushButton.clicked.connect(self.gtps)
        self.retranslateUi(Seat)
        QtCore.QMetaObject.connectSlotsByName(Seat)

    def retranslateUi(self, Seat):
        Seat.setWindowTitle(_translate("Seat", "Form", None))
        self.checkBox_s1.setText(_translate("Seat", "S1", None))
        self.checkBox_s2.setText(_translate("Seat", "S2", None))
        self.checkBox_s3.setText(_translate("Seat", "S3", None))
        self.checkBox_s4.setText(_translate("Seat", "S4", None))
        self.checkBox_s5.setText(_translate("Seat", "S5", None))
        self.checkBox_s6.setText(_translate("Seat", "S6", None))
        self.checkBox_s6_2.setText(_translate("Seat", "S7", None))
        self.checkBox_s7.setText(_translate("Seat", "S8", None))
        self.label.setText(_translate("Seat", "Select Your Seat", None))
        self.pushButton.setText(_translate("Seat", "GO To Passenger Section", None))

    def gtps(self):
        
        self.Passenger_Details = QtGui.QWidget()
        self.ui = Ui_Passenger_Details()
        self.ui.setupUi(self.Passenger_Details)
        self.Passenger_Details.show()


##if __name__ == "__main__":
##    import sys
##    app = QtGui.QApplication(sys.argv)
##    Seat = QtGui.QWidget()
##    ui = Ui_Seat()
##    ui.setupUi(Seat)
##    Seat.show()
##    sys.exit(app.exec_())

